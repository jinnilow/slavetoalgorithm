// CURRENT CODES & REFERENCES :
// [The Coding Train p5.js Tutorials on Youtube]
// [Wave Circle 3 by Richard Bourne]
// [for loop - Change Scale + Slider by jarivkin]
// [2.5: The random() Function - p5.js Tutorial]
// [I.3: noise() vs random() - Perlin Noise and p5.js Tutorial]
// [I.4: Graphing 1D Perlin Noise - Perlin Noise and p5.js Tutorial by The Coding Train]
// [How to display text menu before game starts by Magic Monk on Youtube]
// [Wavemaker from p5js Examples library]
//***************************************************************************//


var mode; //determines whether next page is shown
var bgcolour;
let Slider1, Slider2, Slider3, Slider4, Slider5, Slider6, Slider7, Slider8, Slider9, input, button;
//let textX=500;


var xoff1 = 0; //x offset for slider 6 visual
var xoff2 = 10000;

let t = 0; // time variable

var tri = { //for slider 7 visual
  x1: 10,
  y1: 20,
  x2: 80,
  y2: 90,
  x3: 100,
  y3: 150
}



function setup() {
  mode = 0; //setting landing page
  createCanvas(windowWidth, windowHeight);
  bgcolour = color(0);
  textSize(21);

  //create sliders (min, max, current)
  Slider1 = createSlider(0, 100, 0);
  Slider1.position(30, 110);
  Slider2 = createSlider(0, 100, 0);
  Slider2.position(30, 140);
  Slider3 = createSlider(0, 30, 0);
  Slider3.position(30, 170);
  Slider4 = createSlider(0, 100, 0);
  Slider4.position(30, 200);
  Slider5 = createSlider(0, 1500, 0);
  Slider5.position(30, 230);
  Slider6 = createSlider(0, 50, 0);
  Slider6.position(30, 260);
  Slider7 = createSlider(0, 100, 0);
  Slider7.position(30, 290);
  Slider8 = createSlider(0, 4, 0);
  Slider8.position(30, 320);
  Slider9 = createSlider(0, 4, 0);
  Slider9.position(30, 350);

  //create text box
  let col = color(194, 197, 204);
  input = createInput("");
  input.position(30, 500);
  input.size(230, 10);
  //input.style('background-color',col);


  //create save function
  button = createButton('SAVE');
  button.position(30, 600);
  button.size(60, 30);
  button.mousePressed(save);
  button.style('background-color', col);
}

// function changeColour() {
//   bgcolour = color(random(255));
// }

function draw() {
  background(bgcolour);

  //landing page
  if (mode == 0); {
    fill(255);
    text1 = text('TAKE A DEEP BREATHE. RECALL A MEMORY. PRESS ENTER TO START', 400, 400);
    Slider1.hide();
    Slider2.hide();
    Slider3.hide();
    Slider4.hide();
    Slider5.hide();
    Slider6.hide();
    Slider7.hide();
    Slider8.hide();
    Slider9.hide();

    input.hide();
    button.hide();
  }


  //next web page
  if (mode == 1) {

    text1 = clear();

    Slider1.show();
    Slider2.show();
    Slider3.show();
    Slider4.show();
    Slider5.show();
    Slider6.show();
    Slider7.show();
    Slider8.show();
    Slider9.show();
    input.show();
    button.show();

    background(bgcolour);

    //header
    fill(255);
    textSize(15);
    text('WHAT DO YOU REMEMBER FEELING?', 30, 70);

    //text beside sliders
    textSize(10);
    text('NOSTALGIA', 180, 123);
    text('TRAUMA', 180, 153);
    text('LOVE', 180, 183);
    text('HAPPINESS', 180, 213);
    text('EXCITEMENT', 180, 243);
    text('ANNOYED', 180, 273);
    text('ANXIOUS', 180, 303);
    text('SAD', 180, 333);
    text('REMORSE', 180, 363);

    //input on display
    fill(255);
    textSize(50);
    text(input.value(), 500, 123);
    //text(input.value(), textX, 123);
    // if(textX>width){
    //   textX = textX - 500;
    // }



    //slider1- nostalgia
    fill(255, 0, 175);
    ellipse(400, 150, Slider1.value(), Slider1.value());




    //slider4- happiness
    let x1 = width / 2;
    let y1 = height / 2;

    //make a for loop to move the shape
    for (let happy = 0; happy < Slider4.value(); happy++) {

      noFill(); // no fill
      strokeWeight(0.5);
      stroke(255, 255, 0); // fill yellow

      //use the value of happy to change the scale of each circle
      ellipse(x1, y1, happy * 10, happy * 10);
    }





    //slider5 - excited
    background(0, 30); // translucent background (creates trails)
    noStroke();
    fill(255, 140, 0);
    // make a x and y grid of ellipses
    for (let x = 0; x < Slider5.value(); x = x + 30) {
      for (let y = 0; y < Slider5.value(); y = y + 30) {
        // starting point of each circle depends on mouse position
        const xAngle = map(mouseX, 0, width, -4 * PI, 4 * PI, true);
        const yAngle = map(mouseY, 0, height, -4 * PI, 4 * PI, true);
        // and also varies based on the particle's location
        const angle = xAngle * (x / width) + yAngle * (y / height);

        // each particle moves in a circle
        const myX = x + 20 * cos(2 * PI * t + angle);
        const myY = y + 20 * sin(2 * PI * t + angle);

        ellipse(myX, myY, 10); // draw particle
      }
    }

    t = t + 0.01; // update time




    //slider6 - annoyed
    fill(255);
    //map x value of noise from current range with range of page
    var x = map(noise(xoff1), 0, 1, 0, width);
    var y = map(noise(xoff2), 0, 1, 0, width);

    xoff1 += 1;
    xoff2 += 1; //offset two x values by adding 1 each time

    ellipse(x, y, Slider6.value(), Slider6.value());



    //slider7 - anxious

    //make a for loop to move the shape
    for (let anxious = 0; anxious < Slider7.value(); anxious++) {

      tri.x1 = random(300, 1500);
      tri.y1 = random(0, 900);
      tri.x2 = random(300, 1500);
      tri.y2 = random(0, 900);
      tri.x3 = random(300, 1500);
      tri.y3 = random(0, 900);
      fill(random(0, 255));
      triangle(tri.x1, tri.y1, tri.x2, tri.y2, tri.x3, tri.y3);
      scale(1.5);

    }


    //slider8?
    // stroke(255);
    // noFill();
    // beginShape();
    // for (var z = 0; z < Slide7.value(); z++) {
    //   stroke(255);
    //   vertex(z, random(height));
    // }
    // endShape();

  }


}


//when enter, page changes
function keyPressed() {

  if (keyCode === ENTER) {
    mode = 1;
  }
}
